﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Psalario
{
    public partial class Form1 : Form
    {

        double salarioBruto;

        public Form1()
        {
            InitializeComponent();
        }

        private void txtNomeFunc_Validated(object sender, EventArgs e)
        {
            if (txtNomeFunc.Text == "")
                MessageBox.Show("Nome é inválido");
            foreach (char c in txtNomeFunc.Text)
            {
                if (!char.IsLetter(c))
                {
                    MessageBox.Show("Só aceita letras");
                    break;
                }
            }
        }

        private void mskbxSalarioBruto_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(mskbxSalarioBruto.Text, out salarioBruto))
                MessageBox.Show("Salário Inválido");
            if (salarioBruto <= 0)
                MessageBox.Show("Salário Inválido");
        }

                
        
    }
}
